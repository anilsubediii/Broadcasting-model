<footer style="position: relative; background:#aaa;color:#000;">
	<p>Copyright 2022, All Rights Reserved</p>
	<p class="con">
		<span class="jj">Contact</span>
		<a href="tel:9808894725"><i class="fa fa-phone" aria-hidden="true"></i>
		<a href="https://www.facebook.com/sujan.lama.7330" target="_blank"><i class="fa-brands fa-facebook-f"></i></a>
		<a href="viber://chat?number=9808894725"><i class="fab fa-viber"></i></a>
		<a href="mailto:punitsaur12@gmail.com"><i class="fa fa-envelope" aria-hidden="true"></i></a>
	</p>
	</footer>

	<script type="text/javascript">
		window.addEventListener("scroll",function(){
			var header=document.querySelector("header");
			header.classList.toggle("sticky",window.scrollY>0);
		})
	</script>
</body>
</html>