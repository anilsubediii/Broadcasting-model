<header>
	<a href="index.php" class="logo">broadcast</a>
	<ul>
		<li><a href="index.php" class="active">home</a></li>
		<li><a href="about.html">about</a></li>
		<li class="dropdown"><a href="#" class="dropbtn">resource</a>
			<ul class="dropdown-content">
				<li class="first"><a href="policy.html">Policy</a></li>
				<li><a href="acts.html">Acts & Regulations</a></li>
				<li class="last"><a href="directives.html">Directive & Guideline</a></li>
			</ul>
		</li>
		<li><a href="gallery.html">gallery</a></li>
		<li><a href="contact.html">contact</a></li>
	</ul>
</header>